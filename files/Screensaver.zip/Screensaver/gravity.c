#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <X11/Xlib.h>

#include "vroot.h"

//whether to show the chaos of velocities on the screen
//#define SHOW_CHAOS

//whether to bounce
//#define BOUNCE

//whether to draw particles transparently (broken)
//#define USE_ALPHA

//whether to draw lines
#define DRAW_LINES

//whether to draw polygons
//#define DRAW_POLYGONS

//whether to draw masses
//#define DRAW_MASSES

//whether to draw potential energies
//#define DRAW_ENERGIES

//whether chaos is based on differences between neighbors
#define USE_DIFFS

//number of masses on screen
const int NUM_MASSES = 4;

//number of particles on screen
const int NUM_PARTICLES = 5000;

//bounds on masses
const double MIN_MASS = -1.0;
const double MAX_MASS = 2.0;

//the width and height of the central area in which masses must be
const double MASS_POSITION_LIMIT = 2.0/3;

//the width and height of the central area in which particles must be
const double PARTICLE_POSITION_LIMIT = 1.0; //2.0/3;

//the number of points per side to check for energy
const int ENERGY_CHECKS = 100;

//the maximum count of total (chaos - CHAOS_IDEAL)^2
const double MAX_CHAOS_COUNT = 5000.0;

//penalty per frame if all particles are inside masses.  If fewer are off, penalty is less.
const double INSIDE_MASS_PENALTY = 3.0;

//penalty per frame if all particles are off the screen.  If fewer are off, penalty is less.
const double OFF_SCREEN_PENALTY = 100.0;

//a "penalty" that is always applied.
const double WAIT_PENALTY = 1.0;

//the minimum distance for a polygon to be drawn between particles
const double MAX_PARTICLE_DISTANCE = 0.05;

//For some reason I can't do this, so I use define instead.
//const double MAX_PARTICLE_DISTANCE2 = MAX_PARTICLE_DISTANCE * MAX_PARTICLE_DISTANCE;

#define MAX_PARTICLE_DISTANCE2 (MAX_PARTICLE_DISTANCE * MAX_PARTICLE_DISTANCE)

//the distance between the furthest 2 particles at the beginning.
const double PARTICLE_SPREAD = .0002;

//Increasing this causes different colors to be more spread out.
const double PARTICLE_SPREAD_INT = 0.0; //0.05;

//multiplied by randDouble() for both x and y velocities
const double PARTICLE_VELOCITY_COEFF = 3.0;

//the chaos that causes maximum lifespan
const double CHAOS_IDEAL = 0.0;

//how many steps to do before drawing a new frame
const int STEPS_PER_FRAME = 10;

//how much stuff happens in each frame
const double TIME_PER_FRAME = 0.005; 

//how much stuff happens in each step
#define TIME_STEP (TIME_PER_FRAME / STEPS_PER_FRAME)

//ratio between radius and square root of mass
const double RADIUS_RATIO = 0.04;

//how much to sleep between frames (microseconds)
const int SLEEP_TIME = 0;//1000;


//a particle that moves on the screen
typedef struct {
  double x;
  double y;
  double vx;
  double vy;
  unsigned long color;
} Particle;

//a mass that attracts particles
typedef struct {
  double x;
  double y;
  double mass;
  double radius;
  double radius2;
} Mass;

//the state of the simulation
typedef struct {
  int numParticles;
  Particle *particles;
  int numMasses;
  Mass *masses;
} Simulation;

//random double in [0, 1)
double randDouble() {
  return (double) random() / ((double) (RAND_MAX) + 1.0);
}

//a random number in the range 0.5 += scale / 2
double randScaleHalf(double scale) {
  return randDouble() * scale + (1 - scale) / 2;
}

//get a color
unsigned long getRgbColor(Display *dpy, unsigned short red, unsigned short green, unsigned short blue) {
  XColor color;
  color.red = red;
  color.green = green;
  color.blue = blue;
  color.flags = 0;
  color.pad = 0;
  XAllocColor(
      dpy, DefaultColormapOfScreen(DefaultScreenOfDisplay(dpy)),
      &color);
  return color.pixel;
}

//make a point
XPoint makePoint(short x, short y) {
  XPoint point;
  point.x = x;
  point.y = y;
  return point;
}

double potentialEnergyAt(Simulation sim, double x, double y) {
  double total = 0.0;
  int i;
  for(i = 0; i < sim.numMasses; ++i) {
    Mass m = sim.masses[i];
    double dx = x - m.x;
    double dy = y - m.y;
    double r2 = dx * dx + dy * dy;
    double r = sqrt(r2);
    if(r < m.radius) {
      //integrate mass * x / r dx from 0 to r
      // = mass * r^2 / (2*r)
      // = mass * r / 2
      total += m.mass * r / 2;
    } else {
      total += m.mass * m.radius / 2;
      //integrate mass / x^2 dx from mass's radius to r
      // = [ -mass / x ] from mass's radius to r
      // = -mass * (1 / r - 1 / mr)
      total -= m.mass * (1 / r - 1 / m.radius);
    }
  }
  return total;
}

//re-randomizes the simulation, returning potential energy
double resetSim(Simulation *sim) {
  int numParticles = sim->numParticles;
  int numMasses = sim->numMasses;
  double allX, allY, allVx, allVy, energy;
  int i;
  {
  retry:
    allX = randScaleHalf(PARTICLE_POSITION_LIMIT);
    allY = randScaleHalf(PARTICLE_POSITION_LIMIT);
    allVx = PARTICLE_VELOCITY_COEFF * (randDouble() - 0.5);
    allVy = PARTICLE_VELOCITY_COEFF * (randDouble() - 0.5);
    for(i = 0; i < numMasses; ++i) {
      Mass *m = sim->masses + i;
      m->x = randScaleHalf(MASS_POSITION_LIMIT);
      m->y = randScaleHalf(MASS_POSITION_LIMIT);
      m->mass = randDouble() * (MAX_MASS - MIN_MASS) + MIN_MASS;
      double radius = RADIUS_RATIO * sqrt(fabs(m->mass));
      m->radius = radius;
      m->radius2 = radius * radius;
    }
    energy = (allVx * allVx + allVy * allVy) / 2 
      + potentialEnergyAt(*sim, allX, allY);
    for(i = 0; i < ENERGY_CHECKS; ++i) {
      if(potentialEnergyAt(*sim, 1.0 * i / ENERGY_CHECKS, 0.0) < energy ||
	 potentialEnergyAt(*sim, 1.0, 1.0 * i / ENERGY_CHECKS) < energy ||
	 potentialEnergyAt(*sim, 1.0 - 1.0 * i / ENERGY_CHECKS, 1.0) < energy ||
	 potentialEnergyAt(*sim, 0.0, 1.0 - 1.0 * i / ENERGY_CHECKS) < energy)
	goto retry;
    }
  }
  for(i = 0; i < numParticles; ++i) {
    Particle *p = sim->particles + i;
    p->x = allX - PARTICLE_SPREAD / 2 
      + PARTICLE_SPREAD * i / numParticles
      - PARTICLE_SPREAD_INT * 3
      + PARTICLE_SPREAD_INT * (int) (6 * i / numParticles);
    p->y = allY;
    p->vx = allVx;
    p->vy = allVy;
  }
  
}

//creates and returns a new simulation
Simulation initSim(Display *dpy) {
  Simulation sim;

  sim.numMasses = NUM_MASSES;
  sim.masses = malloc(sizeof(Mass) * sim.numMasses);
  
  sim.numParticles = NUM_PARTICLES;
  Particle *particles = malloc(sizeof(Particle) * sim.numParticles);
  
  int i;
  for(i = 0; i < sim.numParticles; ++i) {
    Particle p;

    //get rgb from hue
    double hue = 6.0 * i / sim.numParticles;
    int ih = floor(hue);
    double f = hue - ih;
    if(ih % 2 == 0) f = 1 - f;
    double n = 1 - f;
    short ns = (short) (n * 0xFFFF);
    double red, green, blue;
    switch(ih) {
    case 0:
      red = 0xFFFF; green = ns; blue = 0; break;
    case 1:
      red = ns; green = 0xFFFF; blue = 0; break;
    case 2:
      red = 0; green = 0xFFFF; blue = ns; break;
    case 3:
      red = 0; green = ns; blue = 0xFFFF; break;
    case 4:
      red = ns; green = 0; blue = 0xFFFF; break;
    case 5:
      red = 0xFFFF; green = 0; blue = ns; break;
    }
    p.color = getRgbColor(dpy, red, green, blue);
    particles[i] = p;
  }
  sim.particles = particles;
  //resetSim(&sim);
  return sim;
}
#ifdef DRAW_POLYGONS
int shouldDrawPoly(int width, int height, short ax, short ay, short bx, short by) {
  double dx = (double) (bx - ax) / width;
  double dy = (double) (by - ay) / height;
  return dx*dx + dy*dy < MAX_PARTICLE_DISTANCE2;
}
#endif

int getRed(unsigned long color) {
  return 0xFF & (color >> 16);
}

int getGreen(unsigned long color) {
  return 0xFF & (color >> 8);
}
int getBlue(unsigned long color) {
  return 0xFF & color;
}

#ifdef USE_ALPHA

void writeLog(char *msg) {
  char sys[1000];
  sprintf(sys, "echo '%s' >> /home/jacobtaylor/Desktop/log.txt", msg);
  system(sys);
}

void drawAlphaPoint(Display *dpy, Window root, GC g, XImage *img, int width, int height, int x, int y, unsigned long color) {
  if(x < 0 || x >= width || y < 0 || y >= width) return;
  unsigned long prev = XGetPixel(img, x, y);
  unsigned long red = (getRed(prev) * 2 + getRed(color)) / 3;
  unsigned long green = (getGreen(prev) * 2 + getGreen(color)) / 3;
  unsigned long blue = (getBlue(prev) * 2 + getBlue(color)) / 3;
  unsigned long newColor = (red << 16) | (green << 8) | blue;
  XSetForeground(dpy, g, newColor);
  XDrawPoint(dpy, root, g, x, y);
}

void drawAlphaLine(Display *dpy, Window root, GC g, XImage *img, int width, int height, int x1, int y1, int x2, int y2, unsigned long color) {
  int dx = x2 - x1;
  int dy = y2 - y1;
  if(dx == 0 && dy == 0) return;
  int adx = dx >= 0 ? dx : -dx;
  int ady = dy >= 0 ? dy : -dy;
  if(adx > ady) {
    double slope = (double) dy / dx;
    int minX, maxX;
    if(dx >= 0) { minX = 0; maxX = dx; }
    else { minX = dx; maxX = 0; }
    int x;
    for(x = minX; x <= maxX; ++x) {
      drawAlphaPoint(dpy, root, g, img, width, height, (int) (x + x1), (int) (slope * x + y1), color);
    }
  } else {
    double slope = (double) dx / dy;
    int minY, maxY;
    if(dy >= 0) { minY = 0; maxY = dy; }
    else { minY = dy; maxY = 0; }
    int y;
    for(y = minY; y <= maxY; ++y) {
      drawAlphaPoint(dpy, root, g, img, width, height, (int) (slope * y + x1), (int) (y + y1), color);
    }
  }
}

#endif





int main ()
{
  srand(time(NULL));

  //open the display (connect to the X server)
  Display *dpy = XOpenDisplay(getenv("DISPLAY"));


  //get the root window
  Window root = DefaultRootWindow(dpy);

  XClearWindow(dpy, root);

 


  //create a GC for drawing in the window
  GC g = XCreateGC(dpy, root, 0, NULL);

  //get window attributes
  XWindowAttributes wa;
  XGetWindowAttributes(dpy, root, &wa);
  int width = wa.width;
  int height = wa.height;

  Simulation sim = initSim(dpy);

  double initEnergy = resetSim(&sim);

  int numParticles = sim.numParticles;
  int numMasses = sim.numMasses;

  #ifdef DRAW_MASSES

  unsigned long posMassColor = getRgbColor(dpy, 0x1000, 0, 0);
  unsigned long negMassColor = getRgbColor(dpy, 0, 0, 0x1000);

  #endif

  #ifdef DRAW_ENERGIES
  unsigned long highEnergyColor = getRgbColor(dpy, 0, 0x1000, 0);
  XPoint *highEnergyPoints = malloc(sizeof(XPoint) * width * height);
  #endif

  
 
  
  for(;;) {

  #ifdef DRAW_ENERGIES 
    {
      int x, y;
      int numHighEnergy = 0;
      for(y = 0; y < height; ++y) {
	double yd = (double) y / height;
	for(x = 0; x < width; ++x) {
	  double xd = (double) x / width;
	  double e = potentialEnergyAt(sim, xd, yd);
	  if(e > initEnergy) {
	    highEnergyPoints[numHighEnergy++] = makePoint(x, y);
	  }
	}
      }
      XSetForeground(dpy, g, highEnergyColor);
      XDrawPoints(dpy, root, g, highEnergyPoints, numHighEnergy, 0);
    }
  
    #endif
    
    #ifdef DRAW_MASSES
    { int mi;
      //draw ellipses for the masses
      for(mi = 0; mi < numMasses; ++mi) {
	Mass m = sim.masses[mi];
	double r = sqrt(m.radius2);
	unsigned long color = m.mass >= 0 ? posMassColor : negMassColor;
	XSetForeground(dpy, g, color);
	XFillArc(dpy, root, g, 
		 (int) (width * (m.x - r)), 
		 (int) (height * (m.y - r)), 
		 (unsigned int) (width * 2 * r), 
		 (unsigned int) (height * 2 * r),
		 0, 360 * 64);
      }
    }

    #endif

    

    
    
    double chaosCount = 0;
    do {

      #ifdef USE_ALPHA
      XImage *img = XGetImage(dpy, root, 0, 0, width, height, 0xFF, XYPixmap);
      #endif

      short prevX1, prevY1, prevX2, prevY2;
      #ifdef USE_DIFFS
      double prevVx = 0;
      double prevVy = 0;
      double totalDiff2 = 0;
      #else
      //for finding standard deviation
      double totalVx = 0;
      double totalVy = 0;
      double totalVx2 = 0;
      double totalVy2 = 0;
      #endif
      int pi;
      for(pi = 0; pi < numParticles; ++pi) {
	Particle *p = sim.particles + pi;
	double oldX = p->x;
	double oldY = p->y;
	int i;
	//step particle STEPS_PER_FRAME times
	for(i = 0; i < STEPS_PER_FRAME; ++i) {
	  double forceX = 0;
	  double forceY = 0;
	  int mi;
	  for(mi = 0; mi < sim.numMasses; ++mi) {
	    Mass m = sim.masses[mi];
	    double dx = m.x - p->x;
	    double dy = m.y - p->y;
	    double dist2 = dx*dx + dy*dy;
	    if(dist2 < m.radius2) {
	      dist2 = m.radius2;
	      chaosCount += INSIDE_MASS_PENALTY / numParticles;
	    }
	    double dist3 = dist2 * sqrt(dist2);
	    if(pi == 0) {
	      //printf("m.x = %f, m.y = %f, dx = %f, dy = %f, dist2 = %f, dist3 = %f\n",
	      //	   m.x, m.y, dx, dy, dist2, dist3);
	    }
	    forceX += m.mass * dx / dist3;
	    forceY += m.mass * dy / dist3;
	  }
	  p->vx += TIME_STEP * forceX;
	  p->vy += TIME_STEP * forceY;
	  
	  p->x += TIME_STEP * p->vx;
	  p->y += TIME_STEP * p->vy;
	}

	

	double vx = p->vx;
	double vy = p->vy;
	#ifdef USE_DIFFS
	if(pi != 0) {
	  double dvx = vx - prevVx;
	  double dvy = vy - prevVy;
	  totalDiff2 += dvx*dvx + dvy*dvy;
	}
	prevVx = vx;
	prevVy = vy;
	#else
	totalVx += vx;
	totalVx2 += vx * vx;
	totalVy += vy;
	totalVy2 += vy * vy;
	#endif

	#ifdef BOUNCE

	if(p->x < 0.0 && vx < 0.0 ||
	   p->x >= 1.0 && vx > 0.0) {
	  p->vx *= -1;
	}

	if(p->y < 0.0 && vy < 0.0 ||
	   p->y >= 1.0 && vy > 0.0) {
	  p->vy *= -1;
	}

	#else

	if(p->x < 0.0 || p->x >= 1.0 ||
	   p->y < 0.0 || p->y >= 1.0) {
	  chaosCount += OFF_SCREEN_PENALTY / numParticles;
	}
	#endif


	#ifdef DRAW_POLYGONS

	short thisX1 = (short) (oldX * width);
	short thisY1 = (short) (oldY * height);
	short thisX2 = (short) (p->x * width);
	short thisY2 = (short) (p->y * height);
	
	if(pi != 0) {
	  XPoint polyPoints[4];
	  polyPoints[0] = makePoint(prevX1, prevY1);
	  polyPoints[1] = makePoint(prevX2, prevY2);
	  polyPoints[2] = makePoint(thisX2, thisY2);
	  polyPoints[3] = makePoint(thisX1, thisY1);

	  if(shouldDrawPoly(width, height, prevX2, prevY2, thisX2, thisY2)) {
	    XSetForeground(dpy, g, p->color);
	    XFillPolygon(dpy, root, g, polyPoints, 4, Complex, CoordModeOrigin);
	  }
	}

	prevX1 = thisX1; prevY1 = thisY1; 
	prevX2 = thisX2; prevY2 = thisY2;

	#endif

	#ifdef DRAW_LINES

	#ifdef USE_ALPHA

	drawAlphaLine(
	  dpy, root, g, img, width, height,
	  (int) (oldX * width), (int) (oldY * height),
	  (int) (p->x * width), (int) (p->y * height), p->color);

	#else

	XSetForeground(dpy, g, p->color);
	XDrawLine(
	  dpy, root, g, 
	  (int) (oldX * width), (int) (oldY * height),
	  (int) (p->x * width), (int) (p->y * height));

	#endif

	#endif

	
      }

      #ifdef USE_ALPHA
      //XPutImage(dpy, root, g, img, 0, 0, 0, 0, width, height);
      #endif

      #ifdef USE_DIFFS

      double chaos = sqrt(totalDiff2 / numParticles);

      #else

      double chaos = 
	sqrt((totalVx2 - (totalVx * totalVx) / numParticles +
              totalVy2 - (totalVy * totalVy) / numParticles)
             / numParticles);

      #endif

      #ifdef SHOW_CHAOS

      char msg[100];
      sprintf(msg, "chaos: %f", chaos);
      XSetForeground(dpy, g, WhitePixelOfScreen(DefaultScreenOfDisplay(dpy)));
      XFillRectangle(dpy, root, g, 0, 0, 100, 10);
      XSetForeground(dpy, g, BlackPixelOfScreen(DefaultScreenOfDisplay(dpy)));
      XDrawString(dpy, root, g, 0, 10, msg, strlen(msg));

      #endif
      
      double chaosDiff = chaos - CHAOS_IDEAL;
      chaosCount += WAIT_PENALTY + chaosDiff * chaosDiff;


      //flush changes and sleep
      XFlush(dpy);
      usleep(SLEEP_TIME);

      
      
    } while(chaosCount < MAX_CHAOS_COUNT);
    
    XClearWindow(dpy, root);
    initEnergy = resetSim(&sim);
  }


  //XCloseDisplay (dpy);
}
