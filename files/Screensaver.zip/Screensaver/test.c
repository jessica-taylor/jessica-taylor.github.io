#include <stdlib.h>
#include <stdio.h>

typedef struct {
  double x;
} Mass;

typedef struct {
  Mass *masses;
} Simulation;



void resetSim(Simulation *sim) {
  Mass onlyMass;
  onlyMass.x = 0.5;
  Mass masses[1];
  masses[0] = onlyMass;
  sim->masses = masses;
  
}



main ()
{

  Simulation sim;
  //resetSim(&sim);

  Mass onlyMass;
  onlyMass.x = 0.5;
  Mass masses[1];
  masses[0] = onlyMass;
  sim.masses = masses;

  printf("mass %f\n", sim.masses[0].x);
  printf("mass %f\n", sim.masses[0].x);

}
