#!/bin/sh -e
gcc -o gravity gravity.c -L/usr/X11R6/lib -lX11 -lm
cp gravity ~/bin
